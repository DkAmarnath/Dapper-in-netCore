﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Dapper;
using Newtonsoft.Json;

namespace DapperWebAPIfor_SQLQueries.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ServiceController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public ActionResult<IEnumerable<string>> Get(string myquery)
        {
            try
            {
                IDbConnection db = new SqlConnection(_configuration.GetConnectionString("DefaultDatabase"));
                // var myquery = "select * from Users";
                // db.Open();
                var result = db.Query(myquery);
                var json = JsonConvert.SerializeObject(result);
                return Ok(json);
            }
            catch(Exception ex)
            {
                return Ok(ex.Message);
            }
        }
    }
}